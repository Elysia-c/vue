<!-- 视图层 -->
<template>
    <div class="top">
        <button>
            <van-icon name="arrow-left" />
        </button>
        <span class="name">张璇</span>
        <div class="evaluate">
            <span>评价</span>
            <van-icon name="manager-o" />
        </div>
    </div>
    <div>

    </div>
</template>

<!-- 逻辑层 -->
<script setup>
</script>

<!-- 样式层 -->
<style lang="less" scoped>
.top{
    display: flex;
    justify-content: space-between;
    height: 5vw;
    font-size: 3vw;
    align-items: center;
    button{
        margin-left: 2vw;
        border: none;
        background-color: transparent;
    }
    .name{
        font-weight: bold;
    }
    .evaluate{
        span{
            color: #78998e;
        }
        margin-right: 2vw;
    }
}
</style>