<!-- 视图层 -->
<template>
    <div>
        <!-- <news/> -->
        <inform/>
    </div>
</template>

<!-- 逻辑层 -->
<script setup>
  // import news from './view/news.vue';
  // import Home from './view/Home.vue';
  import inform from './view/infrom.vue';
    </script>
<!-- 样式层 -->
<style  scoped></style>
